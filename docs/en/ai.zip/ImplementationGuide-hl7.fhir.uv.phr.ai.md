# Resource Personal Health Records



## Resource Content

```json
{
  "resourceType" : "ImplementationGuide",
  "id" : "hl7.fhir.uv.phr",
  "language" : "en",
  "extension" : [
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
      "valueCode" : "trial-use"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
      "valueInteger" : 1
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-wg",
      "valueCode" : "pe"
    }
  ],
  "url" : "http://hl7.org/fhir/uv/phr/ImplementationGuide/hl7.fhir.uv.phr",
  "version" : "1.0.0-ballot2",
  "name" : "PatientHealthRecordsIG",
  "title" : "Personal Health Records",
  "status" : "active",
  "date" : "2026-03-12T15:47:36-05:00",
  "publisher" : "HL7 International / Patient Empowerment",
  "contact" : [
    {
      "name" : "HL7 International / Patient Empowerment",
      "telecom" : [
        {
          "system" : "url",
          "value" : "http://www.hl7.org/Special/committees/patientempowerment"
        }
      ]
    }
  ],
  "description" : "Guidance on how to create longitudinal personal health records using FHIR.  Exporting, file formats, patient examples, and more.",
  "jurisdiction" : [
    {
      "coding" : [
        {
          "system" : "http://unstats.un.org/unsd/methods/m49/m49.htm",
          "code" : "001",
          "display" : "World"
        }
      ]
    }
  ],
  "packageId" : "hl7.fhir.uv.phr",
  "license" : "CC0-1.0",
  "fhirVersion" : ["4.0.1"],
  "dependsOn" : [
    {
      "id" : "hl7tx",
      "extension" : [
        {
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-dependency-comment",
          "valueMarkdown" : "Automatically added as a dependency - all IGs depend on HL7 Terminology"
        }
      ],
      "uri" : "http://terminology.hl7.org/ImplementationGuide/hl7.terminology",
      "packageId" : "hl7.terminology.r4",
      "version" : "7.1.0"
    },
    {
      "id" : "hl7ext",
      "extension" : [
        {
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-dependency-comment",
          "valueMarkdown" : "Automatically added as a dependency - all IGs depend on the HL7 Extension Pack"
        }
      ],
      "uri" : "http://hl7.org/fhir/extensions/ImplementationGuide/hl7.fhir.uv.extensions",
      "packageId" : "hl7.fhir.uv.extensions.r4",
      "version" : "5.2.0"
    },
    {
      "id" : "hl7_fhir_uv_ips",
      "uri" : "http://hl7.org/fhir/uv/ips/ImplementationGuide/hl7.fhir.uv.ips",
      "packageId" : "hl7.fhir.uv.ips",
      "version" : "1.1.0"
    }
  ],
  "definition" : {
    "extension" : [
      {
        "extension" : [
          {
            "url" : "code",
            "valueString" : "copyrightyear"
          },
          {
            "url" : "value",
            "valueString" : "2022+"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueString" : "releaselabel"
          },
          {
            "url" : "value",
            "valueString" : "STU 1 ballot"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueString" : "path-history"
          },
          {
            "url" : "value",
            "valueString" : "http://hl7.org/fhir/uv/phr/history.html"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueString" : "autoload-resources"
          },
          {
            "url" : "value",
            "valueString" : "true"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueString" : "path-liquid"
          },
          {
            "url" : "value",
            "valueString" : "template/liquid"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueString" : "path-liquid"
          },
          {
            "url" : "value",
            "valueString" : "input/liquid"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueString" : "path-qa"
          },
          {
            "url" : "value",
            "valueString" : "temp/qa"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueString" : "path-temp"
          },
          {
            "url" : "value",
            "valueString" : "temp/pages"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueString" : "path-output"
          },
          {
            "url" : "value",
            "valueString" : "output"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueString" : "path-suppressed-warnings"
          },
          {
            "url" : "value",
            "valueString" : "input/ignoreWarnings.txt"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueString" : "template-html"
          },
          {
            "url" : "value",
            "valueString" : "template-page.html"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueString" : "template-md"
          },
          {
            "url" : "value",
            "valueString" : "template-page-md.html"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueString" : "apply-contact"
          },
          {
            "url" : "value",
            "valueString" : "true"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueString" : "apply-context"
          },
          {
            "url" : "value",
            "valueString" : "true"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueString" : "apply-copyright"
          },
          {
            "url" : "value",
            "valueString" : "true"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueString" : "apply-jurisdiction"
          },
          {
            "url" : "value",
            "valueString" : "true"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueString" : "apply-license"
          },
          {
            "url" : "value",
            "valueString" : "true"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueString" : "apply-publisher"
          },
          {
            "url" : "value",
            "valueString" : "true"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueString" : "apply-version"
          },
          {
            "url" : "value",
            "valueString" : "true"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueString" : "apply-wg"
          },
          {
            "url" : "value",
            "valueString" : "true"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueString" : "active-tables"
          },
          {
            "url" : "value",
            "valueString" : "true"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueString" : "fmm-definition"
          },
          {
            "url" : "value",
            "valueString" : "http://hl7.org/fhir/versions.html#maturity"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueString" : "propagate-status"
          },
          {
            "url" : "value",
            "valueString" : "true"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueString" : "excludelogbinaryformat"
          },
          {
            "url" : "value",
            "valueString" : "true"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueString" : "tabbed-snapshots"
          },
          {
            "url" : "value",
            "valueString" : "true"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueString" : "i18n-default-lang"
          },
          {
            "url" : "value",
            "valueString" : "en"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-internal-dependency",
        "valueCode" : "hl7.fhir.uv.tools.r4#0.9.0"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueCode" : "copyrightyear"
          },
          {
            "url" : "value",
            "valueString" : "2022+"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueCode" : "releaselabel"
          },
          {
            "url" : "value",
            "valueString" : "STU 1 ballot"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueCode" : "path-history"
          },
          {
            "url" : "value",
            "valueString" : "http://hl7.org/fhir/uv/phr/history.html"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueCode" : "autoload-resources"
          },
          {
            "url" : "value",
            "valueString" : "true"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueCode" : "path-liquid"
          },
          {
            "url" : "value",
            "valueString" : "template/liquid"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueCode" : "path-liquid"
          },
          {
            "url" : "value",
            "valueString" : "input/liquid"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueCode" : "path-qa"
          },
          {
            "url" : "value",
            "valueString" : "temp/qa"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueCode" : "path-temp"
          },
          {
            "url" : "value",
            "valueString" : "temp/pages"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueCode" : "path-output"
          },
          {
            "url" : "value",
            "valueString" : "output"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueCode" : "path-suppressed-warnings"
          },
          {
            "url" : "value",
            "valueString" : "input/ignoreWarnings.txt"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueCode" : "template-html"
          },
          {
            "url" : "value",
            "valueString" : "template-page.html"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueCode" : "template-md"
          },
          {
            "url" : "value",
            "valueString" : "template-page-md.html"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueCode" : "apply-contact"
          },
          {
            "url" : "value",
            "valueString" : "true"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueCode" : "apply-context"
          },
          {
            "url" : "value",
            "valueString" : "true"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueCode" : "apply-copyright"
          },
          {
            "url" : "value",
            "valueString" : "true"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueCode" : "apply-jurisdiction"
          },
          {
            "url" : "value",
            "valueString" : "true"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueCode" : "apply-license"
          },
          {
            "url" : "value",
            "valueString" : "true"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueCode" : "apply-publisher"
          },
          {
            "url" : "value",
            "valueString" : "true"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueCode" : "apply-version"
          },
          {
            "url" : "value",
            "valueString" : "true"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueCode" : "apply-wg"
          },
          {
            "url" : "value",
            "valueString" : "true"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueCode" : "active-tables"
          },
          {
            "url" : "value",
            "valueString" : "true"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueCode" : "fmm-definition"
          },
          {
            "url" : "value",
            "valueString" : "http://hl7.org/fhir/versions.html#maturity"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueCode" : "propagate-status"
          },
          {
            "url" : "value",
            "valueString" : "true"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueCode" : "excludelogbinaryformat"
          },
          {
            "url" : "value",
            "valueString" : "true"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueCode" : "tabbed-snapshots"
          },
          {
            "url" : "value",
            "valueString" : "true"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueCode" : "i18n-default-lang"
          },
          {
            "url" : "value",
            "valueString" : "en"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      }
    ],
    "resource" : [
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "CodeSystem"
          }
        ],
        "reference" : {
          "reference" : "CodeSystem/appetite-changes-codes"
        },
        "name" : "Appetite Changes Codes",
        "description" : "Codes expressing changes in appetite",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "CodeSystem"
          }
        ],
        "reference" : {
          "reference" : "CodeSystem/body-posture-codes"
        },
        "name" : "Body Posture Codes",
        "description" : "Code for posture",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "ValueSet"
          }
        ],
        "reference" : {
          "reference" : "ValueSet/body-temperature-measurement-location"
        },
        "name" : "Body Temperature Measurement Location Codes",
        "description" : "Code indicating the location where the body temperature was measured",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "CodeSystem"
          }
        ],
        "reference" : {
          "reference" : "CodeSystem/body-temperature-measurement-location-codes"
        },
        "name" : "Body Temperature Measurement Location Codes",
        "description" : "Code indicating the location where the body temperature was measured",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "ConceptMap"
          }
        ],
        "reference" : {
          "reference" : "ConceptMap/symptom-pghd-to-snomedct"
        },
        "name" : "ConceptMapSymptomPGHD2SNOMEDCT",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "ConceptMap"
          }
        ],
        "reference" : {
          "reference" : "ConceptMap/symptom-snomedct-to-pghd"
        },
        "name" : "ConceptMapSymptomSNOMEDCT2PGHD",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "ValueSet"
          }
        ],
        "reference" : {
          "reference" : "ValueSet/observation-ecg-classification-codes"
        },
        "name" : "ECG Classification Codes",
        "description" : "Codes for classification of ECG waveforms",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "CodeSystem"
          }
        ],
        "reference" : {
          "reference" : "CodeSystem/ecg-codes"
        },
        "name" : "ECG Classification Codes",
        "description" : "Codes for ECG and related items",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "CodeSystem"
          }
        ],
        "reference" : {
          "reference" : "CodeSystem/ecg-classification-codes"
        },
        "name" : "ECG Classification Codes",
        "description" : "Codes for classification of ECG waveforms",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "ValueSet"
          }
        ],
        "reference" : {
          "reference" : "ValueSet/observation-ecgcodes"
        },
        "name" : "ECG Lead Codes",
        "description" : "Codes for ECG and related items",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "ValueSet"
          }
        ],
        "reference" : {
          "reference" : "ValueSet/observation-ecg-lead-codes"
        },
        "name" : "ECG Lead Codes",
        "description" : "Codes for ECG induction",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "CodeSystem"
          }
        ],
        "reference" : {
          "reference" : "CodeSystem/ecg-lead-codes"
        },
        "name" : "ECG Lead Codes",
        "description" : "Codes for ECG induction",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "ValueSet"
          }
        ],
        "reference" : {
          "reference" : "ValueSet/observation-ecg-symptoms-status-codes"
        },
        "name" : "ECG Symptoms Status Codes",
        "description" : "Code indicating whether or not the user's symptoms are input during ECG waveform acquisition",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "CodeSystem"
          }
        ],
        "reference" : {
          "reference" : "CodeSystem/ecg-symptoms-status-codes"
        },
        "name" : "ECG Symptoms Status Codes",
        "description" : "Code indicating whether or not the user's symptoms are input during ECG waveform acquisition",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:logical"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/Environmental"
        },
        "name" : "Environmental Observation",
        "description" : "A logical model representing environmental conditions relevant to patient health, such as air quality, temperature, noise, and UV exposure. These factors may be collected by consumer weather stations, smartphone sensors, or wearable devices.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:logical"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/FinancialReceipt"
        },
        "name" : "Financial Receipt",
        "description" : "A logical model for over-the-counter (OTC) health-related purchase receipts. Captures expenses for items such as pharmacy purchases, medical supplies, copays, and wellness products that may not generate a formal insurance Claim resource.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Questionnaire"
          }
        ],
        "reference" : {
          "reference" : "Questionnaire/gad7"
        },
        "name" : "GAD-7 assesment",
        "description" : "GAD-7 Scored Assessment",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "CodeSystem"
          }
        ],
        "reference" : {
          "reference" : "CodeSystem/gad7-risk-codes"
        },
        "name" : "GAD-7 Assesment Risk Codes",
        "description" : "Code for GAD-7 Assesment Risk",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "CodeSystem"
          }
        ],
        "reference" : {
          "reference" : "CodeSystem/hearing-sensitivity-codes"
        },
        "name" : "Hearing Sensitivity Codes",
        "description" : "Code indicating the type of value of the hearing test result",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Patient"
          }
        ],
        "reference" : {
          "reference" : "Patient/jane-doe"
        },
        "name" : "Jane Doe",
        "description" : "A sample patient resource for Jane Doe.",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/PhrPatient"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Composition"
          }
        ],
        "reference" : {
          "reference" : "Composition/jane-doe-composition"
        },
        "name" : "Jane Doe Composition",
        "description" : "A minimal narrative composition for Jane Doe's patient data.",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/PhrComposition"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "DocumentReference"
          }
        ],
        "reference" : {
          "reference" : "DocumentReference/jane-doe-genomics-document"
        },
        "name" : "Jane Doe PDF Report",
        "description" : "A PDF genomics report for Jane Doe regarding celiac disease.",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/PhrDocumentReference"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Media"
          }
        ],
        "reference" : {
          "reference" : "Media/jane-doe-media"
        },
        "name" : "Jane Doe Smartphone Photo",
        "description" : "A JPEG photo taken from Jane Doe's smartphone.",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/PhrMedia"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Provenance"
          }
        ],
        "reference" : {
          "reference" : "Provenance/jane-doe-media-provenance"
        },
        "name" : "Jane Doe's Photo Provenance",
        "description" : "Self-attested provenance record for Jane Doe's smartphone photo.",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/PhrProvenance"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "ValueSet"
          }
        ],
        "reference" : {
          "reference" : "ValueSet/observation-activity-codes"
        },
        "name" : "Observation Activity Codes",
        "description" : "Codes representing activity-related measurement items",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "ValueSet"
          }
        ],
        "reference" : {
          "reference" : "ValueSet/observation-alchol-consumption-codes"
        },
        "name" : "Observation AlcholConsumption Codes",
        "description" : "Codes representing items measured for alcohol consumption",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "ValueSet"
          }
        ],
        "reference" : {
          "reference" : "ValueSet/observation-body-measurements-codes"
        },
        "name" : "Observation BodyMeasurements Codes",
        "description" : "Codes representing measurement items related to physical measurements",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "ValueSet"
          }
        ],
        "reference" : {
          "reference" : "ValueSet/observation-diving-codes"
        },
        "name" : "Observation Diving Codes",
        "description" : "Codes for diving-related measurement items",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "ValueSet"
          }
        ],
        "reference" : {
          "reference" : "ValueSet/observation-gad7-risk-codes"
        },
        "name" : "Observation GAD7 Risk Codes",
        "description" : "Codes representing GAD-7 Assesment Risk measurement items",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "ValueSet"
          }
        ],
        "reference" : {
          "reference" : "ValueSet/observation-hearing-codes"
        },
        "name" : "Observation Hearing Codes",
        "description" : "Code for a measurement item related to hearing",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "ValueSet"
          }
        ],
        "reference" : {
          "reference" : "ValueSet/observation-lab-results-codes"
        },
        "name" : "Observation LabResults Codes",
        "description" : "Codes representing measurement items associated with the inspection",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "ValueSet"
          }
        ],
        "reference" : {
          "reference" : "ValueSet/observation-mind-codes"
        },
        "name" : "Observation Mind Codes",
        "description" : "Codes representing mind measurement items",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "ValueSet"
          }
        ],
        "reference" : {
          "reference" : "ValueSet/observation-mindfulness-codes"
        },
        "name" : "Observation Mindfulness Codes",
        "description" : "Codes representing mindfulness-related measures",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "ValueSet"
          }
        ],
        "reference" : {
          "reference" : "ValueSet/observation-mobility-codes"
        },
        "name" : "Observation Mobility Codes",
        "description" : "Codes representing mobility-related measurement items",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "ValueSet"
          }
        ],
        "reference" : {
          "reference" : "ValueSet/observation-nutrition-codes"
        },
        "name" : "Observation Nutrition Codes",
        "description" : "Codes representing nutrition-related measures",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "CodeSystem"
          }
        ],
        "reference" : {
          "reference" : "CodeSystem/observation-pghd-codes"
        },
        "name" : "Observation PGHD Codes",
        "description" : "Code defining the type of PGHD data",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "ValueSet"
          }
        ],
        "reference" : {
          "reference" : "ValueSet/observation-phq9-risk-codes"
        },
        "name" : "Observation PHQ9Risk Codes",
        "description" : "Codes representing PHQ-9 Assesment Risk measurement items",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "ValueSet"
          }
        ],
        "reference" : {
          "reference" : "ValueSet/observation-reproductive-health-codes"
        },
        "name" : "Observation ReproductiveHealth Codes",
        "description" : "Codes representing reproductive-health-related measures",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "ValueSet"
          }
        ],
        "reference" : {
          "reference" : "ValueSet/observation-scored-assessment-codes"
        },
        "name" : "Observation Scored Assessment Codes",
        "description" : "Code for scored assessment",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "ValueSet"
          }
        ],
        "reference" : {
          "reference" : "ValueSet/observation-selfcare-codes"
        },
        "name" : "Observation SelfCare Codes",
        "description" : "Codes representing selfcare-related measurement items",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "ValueSet"
          }
        ],
        "reference" : {
          "reference" : "ValueSet/observation-sleep-codes"
        },
        "name" : "Observation Sleep Codes",
        "description" : "Codes representing sleep-related measurement items",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "ValueSet"
          }
        ],
        "reference" : {
          "reference" : "ValueSet/observation-state-of-mind-association-codes"
        },
        "name" : "Observation State of Mind Association Codes",
        "description" : "Codes for state of mind association",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "ValueSet"
          }
        ],
        "reference" : {
          "reference" : "ValueSet/observation-scored-assessment-score-codes"
        },
        "name" : "Observation State of Mind Codes",
        "description" : "Codes for state of mind",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "ValueSet"
          }
        ],
        "reference" : {
          "reference" : "ValueSet/observation-state-of-mind-codes"
        },
        "name" : "Observation State of Mind Codes",
        "description" : "Codes for state of mind",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "ValueSet"
          }
        ],
        "reference" : {
          "reference" : "ValueSet/observation-state-of-mind-kind-codes"
        },
        "name" : "Observation State of Mind Kind Codes",
        "description" : "Codes for state of mind kind",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "ValueSet"
          }
        ],
        "reference" : {
          "reference" : "ValueSet/observation-state-of-mind-label-codes"
        },
        "name" : "Observation State of Mind Label Codes",
        "description" : "Codes for state of mind label",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "ValueSet"
          }
        ],
        "reference" : {
          "reference" : "ValueSet/observation-state-of-mind-valence-codes"
        },
        "name" : "Observation State of Mind Valence Codes",
        "description" : "Codes for state of mind valence",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "ValueSet"
          }
        ],
        "reference" : {
          "reference" : "ValueSet/observation-symptom-codes"
        },
        "name" : "Observation Symptom Codes",
        "description" : "Codes representing symptom-related measurement items",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "ValueSet"
          }
        ],
        "reference" : {
          "reference" : "ValueSet/observation-symptom-snomedct-codes"
        },
        "name" : "Observation Symptom SNOMED CT Codes",
        "description" : "Codes representing symptom-related measurement items with SNOMED CT",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "ValueSet"
          }
        ],
        "reference" : {
          "reference" : "ValueSet/observation-uvexposure-codes"
        },
        "name" : "Observation UVExposure Codes",
        "description" : "Codes representing UV Exposure-related measurement items",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "ValueSet"
          }
        ],
        "reference" : {
          "reference" : "ValueSet/observation-vital-signs-codes"
        },
        "name" : "Observation Vitalsigns Codes",
        "description" : "Codes representing vitalsigns-related measurement items",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "ValueSet"
          }
        ],
        "reference" : {
          "reference" : "ValueSet/observation-workout-codes"
        },
        "name" : "Observation Workout Codes",
        "description" : "Codes representing workout-related measurement items",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/pghd-sleep-episode-2"
        },
        "name" : "ObservationSleepEpisodeExample2",
        "description" : "SleepEpisode Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-sleep-episode"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/pcd-sleep-observation"
        },
        "name" : "Patient contributed data: sleep observation",
        "description" : "patient sleep logs recorded by device or app.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "ValueSet"
          }
        ],
        "reference" : {
          "reference" : "ValueSet/pcd-sleep-observation-code"
        },
        "name" : "Patient contributed data: sleep observation code",
        "description" : "This value set includes codes to track patient sleep recorded by device or app",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "ValueSet"
          }
        ],
        "reference" : {
          "reference" : "ValueSet/pcd-sleep-observation-value"
        },
        "name" : "Patient contributed data: sleep stage value",
        "description" : "This value set includes codes to track patient sleep values recorded by device or app",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Bundle"
          }
        ],
        "reference" : {
          "reference" : "Bundle/pdr-message"
        },
        "name" : "PatientDataReceipt Message",
        "description" : "An atomic update to a patient record; sent via a commit/push command and POST or PUT operation.",
        "exampleBoolean" : true
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/PCDSleepObservation-duration-example"
        },
        "name" : "PCDSleepObservation-duration-example",
        "description" : "Example - pcd-sleep-observation duration",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pcd-sleep-observation"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/PCDSleepObservation-stage-example"
        },
        "name" : "PCDSleepObservation-stage-example",
        "description" : "Example - pcd-sleep-observation stage",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pcd-sleep-observation"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/pghd-activity"
        },
        "name" : "PGHD Activity Profile",
        "description" : "This profile defines how to represent Activity.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/pghd-alchol-consumption"
        },
        "name" : "PGHD AlcholConsumption Profile",
        "description" : "This profile defines how to represent AlcholConsumption.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/pghd-alchol-use"
        },
        "name" : "PGHD AlcholUse Profile",
        "description" : "This profile defines how to represent Alchol use.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/pghd-audiogram"
        },
        "name" : "PGHD Audiogram Profile",
        "description" : "This profile defines how to represent Audiogram.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/pghd-blood-glucose"
        },
        "name" : "PGHD BloodGlucose Profile",
        "description" : "This profile defines how to represent blood glucose.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/pghd-bloodpressure"
        },
        "name" : "PGHD BloodPressure Profile",
        "description" : "This profile defines how to represent blood pressure measurements.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/pghd-bmi"
        },
        "name" : "PGHD BMI Profile",
        "description" : "This profile defines how to represent BMI measurements.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/pghd-bodymeasurement"
        },
        "name" : "PGHD Body Measurement Profile",
        "description" : "This profile defines how to represent body measurements.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/pghd-bodyheight"
        },
        "name" : "PGHD BodyHeight Profile",
        "description" : "This profile defines how to represent body height measurements.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/pghd-bodytemperature"
        },
        "name" : "PGHD BodyTemperature Profile",
        "description" : "This profile defines how to represent body temperature measurements.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/pghd-bodyweight"
        },
        "name" : "PGHD BodyWeight Profile",
        "description" : "This profile defines how to represent body weight measurements.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/pghd-cardiac-function"
        },
        "name" : "PGHD Cardiac Function Profile",
        "description" : "This profile defines how to represent Cardiac Function.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/pghd-device"
        },
        "name" : "PGHD Device Profile",
        "description" : "This profile defines the device used for the measurement.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/pghd-diving"
        },
        "name" : "PGHD Diving Profile",
        "description" : "This profile defines how to represent Diving.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/pghd-electrocardiogram"
        },
        "name" : "PGHD Electrocardiogram Profile",
        "description" : "This profile defines how to represent Electrocardiogram.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/pghd-food"
        },
        "name" : "PGHD Food Profile",
        "description" : "This profile defines how to represent Food.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/pghd-hearing"
        },
        "name" : "PGHD Hearing Profile",
        "description" : "This profile defines how to represent Hearing.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/pghd-hearing-sensitivity"
        },
        "name" : "PGHD HearingSensitivity Profile",
        "description" : "This profile defines how to represent HearingSensitivity.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/pghd-heartbeat"
        },
        "name" : "PGHD Heartbeat Profile",
        "description" : "This profile defines how to represent Heartbeat.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/pghd-heartrate"
        },
        "name" : "PGHD HeartRate Profile",
        "description" : "This profile defines how to represent heart rate measurements.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/pghd-medication-adherence"
        },
        "name" : "PGHD Medication Adherence Profile",
        "description" : "This profile defines how to represent medication adherence.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/pghd-medicationadministration-insulin"
        },
        "name" : "PGHD MedicationAdministration Insulin Profile",
        "description" : "This profile defines the administered insulin doses of a patient.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/pghd-medicationdispense"
        },
        "name" : "PGHD MedicationDispense Profile",
        "description" : "This profile defines the dispensing on the part of a pharmacy.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/pghd-mindfulness"
        },
        "name" : "PGHD Mindfulness Profile",
        "description" : "This profile defines how to represent Mindfulness.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/pghd-mobility"
        },
        "name" : "PGHD Mobility Profile",
        "description" : "This profile defines how to represent Mobility.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/pghd-nutrition"
        },
        "name" : "PGHD Nutrition Profile",
        "description" : "This profile defines how to represent Nutrition.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/pghd-oxygenSaturation"
        },
        "name" : "PGHD OxygenSaturation Profile",
        "description" : "This profile defines how to represent oxygen saturation measurements.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/pghd-patient"
        },
        "name" : "PGHD Patient Profile",
        "description" : "This profile defines patient information.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/pghd-pregnancy-status"
        },
        "name" : "PGHD Pregnancy Status Profile",
        "description" : "This profile defines how to represent Pregnancy status.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/pghd-questionnaire"
        },
        "name" : "PGHD Questionnaire Profile",
        "description" : "This profile defines the questionnaire.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/pghd-questionnaire-response"
        },
        "name" : "PGHD QuestionnaireResponse Profile",
        "description" : "This profile defines the QuestionnaireResponse.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/pghd-reproductive-health"
        },
        "name" : "PGHD ReproductiveHealth Profile",
        "description" : "This profile defines how to represent ReproductiveHealth.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/pghd-respiratoryrate"
        },
        "name" : "PGHD RespiratoryRate Profile",
        "description" : "This profile defines how to represent respiratory rate measurements.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/pghd-observation-scored-assessment"
        },
        "name" : "PGHD Scored Assessment Profile",
        "description" : "This profile defines the implementation of the Scored Assessment.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/pghd-selfcare"
        },
        "name" : "PGHD Self Care Profile",
        "description" : "This profile defines how to represent SelfCare.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/pghd-careplan-selfcare"
        },
        "name" : "PGHD SelfCare Plan Profile",
        "description" : "This profile defines the SelfCare Plan.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/pghd-sleep-episode"
        },
        "name" : "PGHD Sleep Episode Profile",
        "description" : "This profile defines how to represent Sleep episode.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/pghd-sleep"
        },
        "name" : "PGHD Sleep Profile",
        "description" : "This profile defines how to represent Sleep.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/pghd-snore-event"
        },
        "name" : "PGHD SnoreEvent Profile",
        "description" : "This profile defines how to represent SnoreEvent.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/pghd-snore-index"
        },
        "name" : "PGHD SnoreIndex Profile",
        "description" : "This profile defines how to represent SnoreIndex.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/pghd-observation-state-of-mind"
        },
        "name" : "PGHD State of Mind Profile",
        "description" : "This profile defines the implementation of the State of Mind.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/pghd-symptom"
        },
        "name" : "PGHD Symptom Profile",
        "description" : "This profile defines how to represent Symptom.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/pghd-testresult"
        },
        "name" : "PGHD Test Result Profile",
        "description" : "This profile defines how to represent TestResult.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/pghd-uvexposure"
        },
        "name" : "PGHD UVExposure Profile",
        "description" : "This profile defines how to represent UVExposure.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/pghd-vitalsigns"
        },
        "name" : "PGHD Vital Signs Profile",
        "description" : "This profile defines how to represent vital signs measurements.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/pghd-voltage-measurement"
        },
        "name" : "PGHD VoltageMeasurement Profile",
        "description" : "This profile defines how to represent VoltageMeasurement.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/pghd-workout"
        },
        "name" : "PGHD Workout Profile",
        "description" : "This profile defines how to represent Workout.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/pghd-activity-activeEnergyBurned"
        },
        "name" : "pghd-activity-activeEnergyBurned",
        "description" : "Activity activeEnergyBurned Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-activity"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/pghd-activity-activeEnergyBurned-underwater-diving"
        },
        "name" : "pghd-activity-activeEnergyBurned-underwaterDiving",
        "description" : "Activity activeEnergyBurned Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-activity"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/pghd-activity-activeEnergyBurned-walking"
        },
        "name" : "pghd-activity-activeEnergyBurned-walking",
        "description" : "Activity activeEnergyBurned Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-activity"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/pghd-activity-appleExerciseTime"
        },
        "name" : "pghd-activity-appleExerciseTime",
        "description" : "Activity appleExerciseTime Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-activity"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/pghd-activity-appleMoveTime"
        },
        "name" : "pghd-activity-appleMoveTime",
        "description" : "Activity appleMoveTime Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-activity"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/pghd-activity-appleStandHour"
        },
        "name" : "pghd-activity-appleStandHour",
        "description" : "Activity appleStandHour Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-activity"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/pghd-activity-basalEnergyBurned"
        },
        "name" : "pghd-activity-basalEnergyBurned",
        "description" : "Activity basalEnergyBurned Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-activity"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/pghd-activity-cyclingCadence"
        },
        "name" : "pghd-activity-cyclingCadence",
        "description" : "Activity cyclingCadence Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-activity"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/pghd-activity-distanceWalkingRunning-walking"
        },
        "name" : "pghd-activity-distanceWalkingRunning-walking",
        "description" : "Activity distanceWalkingRunning Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-activity"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/pghd-alchol-consumption-blood-alcohol-content"
        },
        "name" : "pghd-alchol-consumption-bloodAlcoholContent",
        "description" : "AlcholConsumption bloodAlcoholContent Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-alchol-consumption"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/pghd-alchol-use-number-of-alcoholic-beverages"
        },
        "name" : "pghd-alchol-use-numberOfAlcoholicBeverages",
        "description" : "AlcholUse numberOfAlcoholicBeverages Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-alchol-use"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/pghd-audiogram"
        },
        "name" : "pghd-audiogram",
        "description" : "Audiogram Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-audiogram"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/pghd-blood-glucose-1"
        },
        "name" : "pghd-blood-glucose-1",
        "description" : "BloodGlucose Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-blood-glucose"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/pghd-blood-glucose-2"
        },
        "name" : "pghd-blood-glucose-2",
        "description" : "BloodGlucose Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-blood-glucose"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/pghd-blood-glucose-3"
        },
        "name" : "pghd-blood-glucose-3",
        "description" : "BloodGlucose Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-blood-glucose"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/pghd-bloodpressure"
        },
        "name" : "pghd-bloodpressure",
        "description" : "BloodPressure Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-bloodpressure"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/pghd-bmi"
        },
        "name" : "pghd-bmi",
        "description" : "BMI Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-bmi"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/pghd-bodyheight"
        },
        "name" : "pghd-bodyheight",
        "description" : "BodyHeight Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-bodyheight"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/pghd-bodymeasurement-body-fat-percentage"
        },
        "name" : "pghd-bodymeasurement",
        "description" : "BodyMeasurement bodyFatPercentage Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-bodymeasurement"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/pghd-bodytemperature"
        },
        "name" : "pghd-bodytemperature",
        "description" : "BodyTemperature Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-bodytemperature"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/pghd-bodyweight"
        },
        "name" : "pghd-bodyweight",
        "description" : "Body Weight Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-bodyweight"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/pghd-cardiac-function-lowHeart-rate-event"
        },
        "name" : "pghd-cardiac-function-lowHeartRateEvent",
        "description" : "CardiacFunction lowHeartRateEvent Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-cardiac-function"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/pghd-diving-underwater-depthg"
        },
        "name" : "pghd-diving-underwaterDepth",
        "description" : "Diving underwaterDepth Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-diving"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/pghd-diving-water-temperature"
        },
        "name" : "pghd-diving-waterTemperature",
        "description" : "Diving waterTemperature Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-diving"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/pghd-food"
        },
        "name" : "pghd-food",
        "description" : "Food Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-food"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/pghd-hearing-environmental-audio-exposure"
        },
        "name" : "pghd-hearing-environmentalAudioExposure",
        "description" : "Hearing environmentalAudioExposure Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-hearing"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/pghd-hearingSensitivity-1"
        },
        "name" : "pghd-hearingSensitivity-1",
        "description" : "HearingSensitivity Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-hearing-sensitivity"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/pghd-hearingSensitivity-2"
        },
        "name" : "pghd-hearingSensitivity-2",
        "description" : "HearingSensitivity Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-hearing-sensitivity"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/pghd-hearingSensitivity-3"
        },
        "name" : "pghd-hearingSensitivity-3",
        "description" : "HearingSensitivity Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-hearing-sensitivity"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/pghd-hearingSensitivity-4"
        },
        "name" : "pghd-hearingSensitivity-4",
        "description" : "HearingSensitivity Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-hearing-sensitivity"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/pghd-heart-electrocardiogram"
        },
        "name" : "pghd-heart-electrocardiogram",
        "description" : "Heart electrocardiogram Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-electrocardiogram"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/pghd-heartbeat"
        },
        "name" : "pghd-heartbeat",
        "description" : "Heartbeat Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-heartbeat"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/pghd-heartrate"
        },
        "name" : "pghd-heartrate",
        "description" : "HeartRate Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-heartrate"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/pghd-medication-adherence"
        },
        "name" : "pghd-medication-adherence",
        "description" : "MedicationAdherence Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-medication-adherence"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "MedicationAdministration"
          }
        ],
        "reference" : {
          "reference" : "MedicationAdministration/pghd-medicationadministration-insulin-1"
        },
        "name" : "pghd-medicationadministration-insulin",
        "description" : "MedicationAdministration Insulin Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-medicationadministration-insulin"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/pghd-mindfulness-mindful-session"
        },
        "name" : "pghd-mindfulness-mindfulSession",
        "description" : "Mindfulness Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-mindfulness"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/pghd-mobility-stair-descent-speed"
        },
        "name" : "pghd-mobility-stairDescentSpeed",
        "description" : "Mobility stairDescentSpeed Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-mobility"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/pghd-nutrition-dietary-carbohydrates"
        },
        "name" : "pghd-nutrition-dietaryCarbohydrates",
        "description" : "Nutrition dietaryCarbohydrates Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-nutrition"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/pghd-nutrition-dietary-energy-consumed"
        },
        "name" : "pghd-nutrition-dietaryEnergyConsumed",
        "description" : "Nutrition dietaryEnergyConsumed Example",
        "exampleBoolean" : true
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/pghd-nutrition-dietary-fiber"
        },
        "name" : "pghd-nutrition-dietaryFiber",
        "description" : "Nutrition dietaryFiber Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-nutrition"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/pghd-nutrition-dietary-protein"
        },
        "name" : "pghd-nutrition-dietaryProtein",
        "description" : "Nutrition dietaryProtein Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-nutrition"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/pghd-oxygenSaturation"
        },
        "name" : "pghd-oxygenSaturation",
        "description" : "OxygenSaturation Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-oxygenSaturation"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/pghd-pregnancy-status"
        },
        "name" : "pghd-pregnancy-status",
        "description" : "PregnancyStatus Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-pregnancy-status"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/pghd-reproductive-health-intermenstrual-bleeding"
        },
        "name" : "pghd-reproductive-health-intermenstrualBleeding",
        "description" : "ReproductiveHealth intermenstrualBleeding Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-reproductive-health"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/pghd-respiratoryrate"
        },
        "name" : "pghd-respiratoryrate",
        "description" : "RespiratoryRate Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-respiratoryrate"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/pghd-selfcare-handwashingEvent"
        },
        "name" : "pghd-selfcare-handwashingEvent",
        "description" : "SelfCare handwashingEvent Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-selfcare"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/pghd-sleep-asleep-core"
        },
        "name" : "pghd-sleep-asleepCore",
        "description" : "Sleep asleepCore Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-sleep"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/pghd-sleep-episode-1"
        },
        "name" : "pghd-sleep-episode-1",
        "description" : "SleepEpisode Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-sleep-episode"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/pghd-sleep-episode-core-sleep-1"
        },
        "name" : "pghd-sleep-episode-core-sleep-1",
        "description" : "SleepEpisode Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-sleep-episode"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/pghd-sleep-episode-core-sleep-2"
        },
        "name" : "pghd-sleep-episode-core-sleep-2",
        "description" : "SleepEpisode Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-sleep-episode"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/pghd-sleep-episode-deep-sleep-2"
        },
        "name" : "pghd-sleep-episode-deep-sleep-",
        "description" : "SleepEpisode Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-sleep-episode"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/pghd-sleep-episode-deep-sleep-1"
        },
        "name" : "pghd-sleep-episode-deep-sleep-1",
        "description" : "SleepEpisode Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-sleep-episode"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/pghd-sleep-episode-latency-to-sleep-onset-1"
        },
        "name" : "pghd-sleep-episode-latency-to-sleep-onset-1",
        "description" : "SleepEpisode Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-sleep-episode"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/pghd-sleep-episode-latency-to-sleep-onset-2"
        },
        "name" : "pghd-sleep-episode-latency-to-sleep-onset-2",
        "description" : "SleepEpisode Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-sleep-episode"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/pghd-snore-event-1"
        },
        "name" : "pghd-snore-event-1",
        "description" : "SnoreIndex Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-snore-event"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/pghd-snore-event-2"
        },
        "name" : "pghd-snore-event-2",
        "description" : "SnoreIndex Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-snore-event"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/pghd-snore-event-3"
        },
        "name" : "pghd-snore-event-3",
        "description" : "SnoreIndex Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-snore-event"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/pghd-snore-index-1"
        },
        "name" : "pghd-snore-index-",
        "description" : "SnoreIndex Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-snore-index"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/pghd-snore-index-2"
        },
        "name" : "pghd-snore-index-2",
        "description" : "SnoreIndex Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-snore-index"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/pghd-symptom-fever"
        },
        "name" : "pghd-symptom-fever",
        "description" : "Symptom fever Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-symptom"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/pghd-testresult-forced-vital-capacity"
        },
        "name" : "pghd-testresult-forcedVitalCapacity",
        "description" : "TestResult forcedVitalCapacity Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-testresult"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/pghd-uvexposure"
        },
        "name" : "pghd-uvexposure",
        "description" : "UVExposure Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-uvexposure"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/pghd-vitalsigns-apple-sleeping-wrist-temperature"
        },
        "name" : "pghd-vitalsigns-appleSleepingWristTemperature",
        "description" : "VitalSigns appleSleepingWristTemperature Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-vitalsigns"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/pghd-voltage-measurement"
        },
        "name" : "pghd-voltage-measurement",
        "description" : "VoltageMeasurement Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-voltage-measurement"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/pghd-workout-underwater-diving"
        },
        "name" : "pghd-workout-underwaterDiving",
        "description" : "Workout underwaterDiving Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-workout"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/pghd-workout-walking"
        },
        "name" : "pghd-workout-walking",
        "description" : "Workout walking Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-workout"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Patient"
          }
        ],
        "reference" : {
          "reference" : "Patient/1"
        },
        "name" : "PGHDPatientExample",
        "description" : "Patient Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-patient"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Questionnaire"
          }
        ],
        "reference" : {
          "reference" : "Questionnaire/phq9"
        },
        "name" : "PHQ-9 assesment",
        "description" : "PHQ-9 Scored Assessment",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "CodeSystem"
          }
        ],
        "reference" : {
          "reference" : "CodeSystem/phq9-risk-codes"
        },
        "name" : "PHQ-9 Assesment Risk Codes",
        "description" : "Code for PHQ-9 Assesment Risk",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/PhrBundle"
        },
        "name" : "PhrBundle",
        "description" : "Standard PHR profile of the Bundle resource.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Bundle"
          }
        ],
        "reference" : {
          "reference" : "Bundle/PhrBundle-example"
        },
        "name" : "PhrBundle-example",
        "description" : "Jane Doe - PhrBundle",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/PhrBundle"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/PhrComposition"
        },
        "name" : "PhrComposition",
        "description" : "Standard PHR profile of the Composition resource.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/PhrDocumentReference"
        },
        "name" : "PhrDocumentReference",
        "description" : "Standard PHR profile of the DocumentReference resource.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/PhrMedia"
        },
        "name" : "PhrMedia",
        "description" : "Standard PHR profile of the Media resource.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/PhrPatient"
        },
        "name" : "PhrPatient",
        "description" : "Standard PHR profile of the Patient resource.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/PhrProvenance"
        },
        "name" : "PhrProvenance",
        "description" : "Standard PHR profile of the Provenance resource.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "QuestionnaireResponse"
          }
        ],
        "reference" : {
          "reference" : "QuestionnaireResponse/gad7"
        },
        "name" : "QuestionnaireResponseScoredAssessmentGAD7Example",
        "description" : "GAD-7 Scored Assessment Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-questionnaire-response"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "QuestionnaireResponse"
          }
        ],
        "reference" : {
          "reference" : "QuestionnaireResponse/phq9"
        },
        "name" : "QuestionnaireResponseScoredAssessmentPHQ9Example",
        "description" : "PHQ-9 Scored Assessment Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-questionnaire-response"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "CodeSystem"
          }
        ],
        "reference" : {
          "reference" : "CodeSystem/scored-assessment-codes"
        },
        "name" : "Scored Assessment Codes",
        "description" : "Code for scored assessment",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/ScoredAssessmentGAD7Example"
        },
        "name" : "ScoredAssessmentGAD7Example",
        "description" : "GAD-7 Scored Assessment Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-observation-scored-assessment"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/ScoredAssessmentPHQ9Example"
        },
        "name" : "ScoredAssessmentPHQ9Example",
        "description" : "PHQ-9 Scored Assessment Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-observation-scored-assessment"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "SearchParameter"
          }
        ],
        "reference" : {
          "reference" : "SearchParameter/patient-identifier"
        },
        "name" : "Search by identifier in patient with multipleOr",
        "description" : "This SearchParameter enables query of patient by `identifier` with `mutlipleOr` enabled.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "SearchParameter"
          }
        ],
        "reference" : {
          "reference" : "SearchParameter/search-from-date"
        },
        "name" : "Search From Date",
        "description" : "Return records from this date",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "ValueSet"
          }
        ],
        "reference" : {
          "reference" : "ValueSet/sleep-analysis"
        },
        "name" : "Sleep Analysis",
        "description" : "Codes for stages of sleep",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "CodeSystem"
          }
        ],
        "reference" : {
          "reference" : "CodeSystem/sleep-analysis-codes"
        },
        "name" : "Sleep Analysis Codes",
        "description" : "Codes for stages of sleep",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "CodeSystem"
          }
        ],
        "reference" : {
          "reference" : "CodeSystem/sleep-episode-codes"
        },
        "name" : "Sleep Episode Codes",
        "description" : "Codes for sleep episodes",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "CodeSystem"
          }
        ],
        "reference" : {
          "reference" : "CodeSystem/snore-event-item-codes"
        },
        "name" : "Snore Event Item Codes",
        "description" : "Code representing the measurement used in the snoring event",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:logical"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/SocialMedia"
        },
        "name" : "Social Media Post",
        "description" : "A logical model representing a social media post from platforms such as Facebook, Instagram, Twitter/X, Tumblr, etc. Captures the post content, media attachments, and metadata. Relevant for patient-reported outcomes, behavioral health context, and longitudinal health narratives.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "CodeSystem"
          }
        ],
        "reference" : {
          "reference" : "CodeSystem/state-of-mind-association-codes"
        },
        "name" : "State of Mind Association Codes",
        "description" : "Codes for state of mind association",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "CodeSystem"
          }
        ],
        "reference" : {
          "reference" : "CodeSystem/state-of-mind-codes"
        },
        "name" : "State of Mind Codes",
        "description" : "Code for state of mind",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "CodeSystem"
          }
        ],
        "reference" : {
          "reference" : "CodeSystem/state-of-mind-kind-codes"
        },
        "name" : "State of Mind Kind Codes",
        "description" : "Codes for state of mind kind",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "CodeSystem"
          }
        ],
        "reference" : {
          "reference" : "CodeSystem/state-of-mind-label-codes"
        },
        "name" : "State of Mind Label Codes",
        "description" : "Codes for state of mind label",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "CodeSystem"
          }
        ],
        "reference" : {
          "reference" : "CodeSystem/state-of-mind-valence-codes"
        },
        "name" : "State of Mind Valence Codes",
        "description" : "Codes for state of mind valence",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/StateOfMind2Example"
        },
        "name" : "StateOfMind2Example",
        "description" : "State of Mind Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-observation-state-of-mind"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Observation"
          }
        ],
        "reference" : {
          "reference" : "Observation/StateOfMindExample"
        },
        "name" : "StateOfMindExample",
        "description" : "State of Mind Example",
        "exampleCanonical" : "http://hl7.org/fhir/uv/phr/StructureDefinition/pghd-observation-state-of-mind"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "ValueSet"
          }
        ],
        "reference" : {
          "reference" : "ValueSet/appetite-changes"
        },
        "name" : "Symptom Appetite Changes",
        "description" : "Codes expressing changes in appetite",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "ValueSet"
          }
        ],
        "reference" : {
          "reference" : "ValueSet/symptom-presence"
        },
        "name" : "Symptom Presence",
        "description" : "Code for presence or absence of symptoms",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "CodeSystem"
          }
        ],
        "reference" : {
          "reference" : "CodeSystem/presence-codes"
        },
        "name" : "Symptom Presence Codes",
        "description" : "Code for presence or absence of symptoms",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "ValueSet"
          }
        ],
        "reference" : {
          "reference" : "ValueSet/symptom-severity"
        },
        "name" : "Symptom Severity",
        "description" : "Code for degree of symptoms",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "CodeSystem"
          }
        ],
        "reference" : {
          "reference" : "CodeSystem/symptom-severity-codes"
        },
        "name" : "Symptom Severity Codes",
        "description" : "Code for degree of symptoms",
        "exampleBoolean" : false
      }
    ],
    "page" : {
      "extension" : [
        {
          "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
          "valueCode" : "informative"
        },
        {
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "toc.html"
        }
      ],
      "nameUrl" : "toc.html",
      "title" : "Table of Contents",
      "generation" : "html",
      "page" : [
        {
          "extension" : [
            {
              "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
              "valueCode" : "informative"
            },
            {
              "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
              "valueUrl" : "index.html"
            }
          ],
          "nameUrl" : "index.html",
          "title" : "Getting Started",
          "generation" : "markdown"
        },
        {
          "extension" : [
            {
              "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
              "valueCode" : "informative"
            },
            {
              "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
              "valueUrl" : "recordkeeping.html"
            }
          ],
          "nameUrl" : "recordkeeping.html",
          "title" : "Record Keeping",
          "generation" : "markdown"
        },
        {
          "extension" : [
            {
              "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
              "valueCode" : "informative"
            },
            {
              "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
              "valueUrl" : "conformance.html"
            }
          ],
          "nameUrl" : "conformance.html",
          "title" : "Conformance Recommendations",
          "generation" : "markdown"
        },
        {
          "extension" : [
            {
              "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
              "valueCode" : "informative"
            },
            {
              "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
              "valueUrl" : "datamodel.html"
            }
          ],
          "nameUrl" : "datamodel.html",
          "title" : "Data Model",
          "generation" : "markdown"
        },
        {
          "extension" : [
            {
              "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
              "valueCode" : "informative"
            },
            {
              "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
              "valueUrl" : "functionality.html"
            }
          ],
          "nameUrl" : "functionality.html",
          "title" : "Functional Model",
          "generation" : "markdown"
        },
        {
          "extension" : [
            {
              "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
              "valueCode" : "informative"
            },
            {
              "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
              "valueUrl" : "recordlifecycle.html"
            }
          ],
          "nameUrl" : "recordlifecycle.html",
          "title" : "Record Lifecycle",
          "generation" : "markdown"
        },
        {
          "extension" : [
            {
              "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
              "valueCode" : "informative"
            },
            {
              "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
              "valueUrl" : "annotations.html"
            }
          ],
          "nameUrl" : "annotations.html",
          "title" : "Annotations",
          "generation" : "markdown"
        },
        {
          "extension" : [
            {
              "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
              "valueCode" : "informative"
            },
            {
              "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
              "valueUrl" : "security.html"
            }
          ],
          "nameUrl" : "security.html",
          "title" : "Security",
          "generation" : "markdown"
        },
        {
          "extension" : [
            {
              "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
              "valueCode" : "informative"
            },
            {
              "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
              "valueUrl" : "history.html"
            }
          ],
          "nameUrl" : "history.html",
          "title" : "History",
          "generation" : "markdown"
        },
        {
          "extension" : [
            {
              "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
              "valueCode" : "informative"
            },
            {
              "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
              "valueUrl" : "physiology.html"
            }
          ],
          "nameUrl" : "physiology.html",
          "title" : "Physiology Domains",
          "generation" : "markdown"
        },
        {
          "extension" : [
            {
              "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
              "valueCode" : "informative"
            },
            {
              "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
              "valueUrl" : "personas.html"
            }
          ],
          "nameUrl" : "personas.html",
          "title" : "Patient Personas",
          "generation" : "markdown"
        },
        {
          "extension" : [
            {
              "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
              "valueCode" : "informative"
            },
            {
              "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
              "valueUrl" : "persona-william.html"
            }
          ],
          "nameUrl" : "persona-william.html",
          "title" : "William Sim",
          "generation" : "markdown"
        },
        {
          "extension" : [
            {
              "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
              "valueCode" : "informative"
            },
            {
              "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
              "valueUrl" : "persona-thompson-family.html"
            }
          ],
          "nameUrl" : "persona-thompson-family.html",
          "title" : "Thompson Family",
          "generation" : "markdown"
        },
        {
          "extension" : [
            {
              "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
              "valueCode" : "informative"
            },
            {
              "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
              "valueUrl" : "persona-journey-a.html"
            }
          ],
          "nameUrl" : "persona-journey-a.html",
          "title" : "Anne",
          "generation" : "markdown"
        },
        {
          "extension" : [
            {
              "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
              "valueCode" : "informative"
            },
            {
              "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
              "valueUrl" : "persona-journey-b.html"
            }
          ],
          "nameUrl" : "persona-journey-b.html",
          "title" : "Earl",
          "generation" : "markdown"
        },
        {
          "extension" : [
            {
              "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
              "valueCode" : "informative"
            },
            {
              "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
              "valueUrl" : "persona-journey-c.html"
            }
          ],
          "nameUrl" : "persona-journey-c.html",
          "title" : "Markus",
          "generation" : "markdown"
        },
        {
          "extension" : [
            {
              "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
              "valueCode" : "informative"
            },
            {
              "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
              "valueUrl" : "persona-journey-d.html"
            }
          ],
          "nameUrl" : "persona-journey-d.html",
          "title" : "Wilma",
          "generation" : "markdown"
        },
        {
          "extension" : [
            {
              "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
              "valueCode" : "informative"
            },
            {
              "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
              "valueUrl" : "persona-journey-e.html"
            }
          ],
          "nameUrl" : "persona-journey-e.html",
          "title" : "Marcella",
          "generation" : "markdown"
        },
        {
          "extension" : [
            {
              "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
              "valueCode" : "informative"
            },
            {
              "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
              "valueUrl" : "personas-index.html"
            }
          ],
          "nameUrl" : "personas-index.html",
          "title" : "Personas Index",
          "generation" : "markdown"
        },
        {
          "extension" : [
            {
              "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
              "valueCode" : "informative"
            },
            {
              "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
              "valueUrl" : "operating-systems.html"
            }
          ],
          "nameUrl" : "operating-systems.html",
          "title" : "Operating Systems",
          "generation" : "markdown"
        },
        {
          "extension" : [
            {
              "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
              "valueCode" : "informative"
            },
            {
              "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
              "valueUrl" : "algorithms.html"
            }
          ],
          "nameUrl" : "algorithms.html",
          "title" : "Algorithms",
          "generation" : "markdown"
        },
        {
          "extension" : [
            {
              "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
              "valueCode" : "informative"
            },
            {
              "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
              "valueUrl" : "api.html"
            }
          ],
          "nameUrl" : "api.html",
          "title" : "API Endpoints",
          "generation" : "markdown"
        },
        {
          "extension" : [
            {
              "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
              "valueCode" : "informative"
            },
            {
              "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
              "valueUrl" : "longitudinal.html"
            }
          ],
          "nameUrl" : "longitudinal.html",
          "title" : "Longitudinal Records",
          "generation" : "markdown"
        },
        {
          "extension" : [
            {
              "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
              "valueCode" : "informative"
            },
            {
              "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
              "valueUrl" : "pghd.html"
            }
          ],
          "nameUrl" : "pghd.html",
          "title" : "Patient-generated health data(PGHD)",
          "generation" : "markdown"
        },
        {
          "extension" : [
            {
              "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
              "valueCode" : "informative"
            },
            {
              "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
              "valueUrl" : "logical-models.html"
            }
          ],
          "nameUrl" : "logical-models.html",
          "title" : "Logical Models",
          "generation" : "markdown"
        }
      ]
    },
    "parameter" : [
      {
        "code" : "path-resource",
        "value" : "input/capabilities"
      },
      {
        "code" : "path-resource",
        "value" : "input/examples"
      },
      {
        "code" : "path-resource",
        "value" : "input/extensions"
      },
      {
        "code" : "path-resource",
        "value" : "input/models"
      },
      {
        "code" : "path-resource",
        "value" : "input/operations"
      },
      {
        "code" : "path-resource",
        "value" : "input/profiles"
      },
      {
        "code" : "path-resource",
        "value" : "input/resources"
      },
      {
        "code" : "path-resource",
        "value" : "input/vocabulary"
      },
      {
        "code" : "path-resource",
        "value" : "input/maps"
      },
      {
        "code" : "path-resource",
        "value" : "input/testing"
      },
      {
        "code" : "path-resource",
        "value" : "input/history"
      },
      {
        "code" : "path-resource",
        "value" : "fsh-generated/resources"
      },
      {
        "code" : "path-pages",
        "value" : "template/config"
      },
      {
        "code" : "path-pages",
        "value" : "input/assets"
      },
      {
        "code" : "path-pages",
        "value" : "input/images"
      },
      {
        "code" : "path-tx-cache",
        "value" : "input-cache/txcache"
      }
    ]
  }
}

```
