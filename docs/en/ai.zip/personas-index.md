# Personas Index - Personal Health Records v1.0.0-ballot2

## Personas Index

One of the most challenging aspects of programming a Personal Health Record is developing a longitudinal record to use as a baseline. Rather than specify what functionality should be included the PHR, this implementation guide endeavors to define **patient persona benchmarks** that PHRs should be able to either consume or generate.

It is our hope that your applications should be able to load any of the following PHR files and not error out or fail. That is not to say that your application ought to use all of the data in the following records; rather, it simply needs to be able to parse the record-keeping of a file format that can contain large DICOM files, crypotographically signed provenance records, patient data receipts, and other recordkeeping structures that we see in the PHR ecosystem.

### Interesting Case File

| | | | | | |
| :--- | :--- | :--- | :--- | :--- | :--- |
| john-doe | John Doe | Diabetic |   | [JohnDoe.phr](JohnDoe.phr) |   |
| jenny-m | Jenny M | Cancer | MCODE | [JennyM-cancer-patient.phr](JennyM-cancer-patient.phr) |   |
| betsy | Betsy Johnson |   | PACIO | [BetsySmithJohnson.phr](PACIO/BetsySmithJohnson.phr) |   |
| wsim001 | William Sim | Pediatric Cancer | DICOM | [WilliamSim.phr](WilliamSim.phr) | [WilliamSim.sphr](WilliamSim.sphr) |
| 1 | Patricia Noelle | Asthma | MCC eCarePlan | [PatriciaNoelle.phr](eCarePlan/PatriciaNoelle-cc-pat-pnoelle.phr) |   |
| A | Anne | Patient relocation | Patient Journeys | [AnnGoodwin.phr](PatientJourneys/Anne_Goodwin_6a9e8e6f-d4d8-f062-79cf-cbeda88dc2bf.phr) |   |
| B | Earl | Cancer diagnosis | Patient Journeys | [EarlCarillo.phr](PatientJourneys/Earl_Carrillo_13803def-e365-e248-e7ec-632533574c3c.phr) |   |
| C | Markus | Cardiac Rehabilitation | Patient Journeys | [MarkusWard.phr](PatientJourneys/Markus_Ward_69437c6f-772f-6aaf-34b9-b4d3f12d9eaf.phr) |   |
| D | Wilma | Long COVID | Patient Journeys | [WilmaNader.phr](PatientJourneys/Wilma_Nader_24f4d2f1-b4ef-0654-25a3-bdce21e7ceef.phr) |   |
| E | Marcella | Complex chronic illness | Patient Journeys | [MarcellaSchumm.phr](PatientJourneys/Marcella_Schumm_a6e749b3-eff6-94d5-5ee2-fb4a6566deef.phr) |   |
| E | Spencer | Childhood Leukemia | Thompson Family Usecase | [SpencerThompson.phr](PatientJourneys/Spencer_Thompson_ae26bfd6-d45b-c819-0de6-a2299511e6f4.phr) |   |
| X12 | Jamie | Diabetes | GoInvo |   |   |
| Y48 | Alyssa | Pregnancy | GoInvo |   |   |
| H32 | Choko | Asthma and back pain | GoInvo |   |   |
| J02 | Tommy | Obese and prediabetic | GoInvo |   |   |
| N76 | Naja | Rare familial development disorders | GoInvo |   |   |
| G43 | Sammy | COPD and Alzheimers | GoInvo |   |   |
| J97 | Allison | Single mother | GoInvo |   |   |

### Synthetic Patients (Synthea)

| | | | | | |
| :--- | :--- | :--- | :--- | :--- | :--- |
| b031fa19-1e03-42e0-19de-f60c9dc2a579 | Adelina682 Walker122 | allergies | 170837001 | [json](Adelina682_Walker122_b031fa19-1e03-42e0-19de-f60c9dc2a579.json) | [phr](Ms.Adelina682Walker122-b031fa19-1e03-42e0-19de-f60c9dc2a579.phr) |
| ae26bfd6-d45b-c819-0de6-a2299511e6f4 | Spencer Thompson | acute myeloid leukemia | 91861009 | [json](PatientJourneys/Spencer_Thompson_ae26bfd6-d45b-c819-0de6-a2299511e6f4.json) | [phr](PatientJourneys/Spencer_Thompson_ae26bfd6-d45b-c819-0de6-a2299511e6f4.phr) |
| 521a2b92-7926-4348-0c8d-3bd3af6da538 | Maegan141 Cole117 | seasonal allergic rhinitis | 367498001 | [json](Maegan141_Cole117_521a2b92-7926-4348-0c8d-3bd3af6da538.json) | [phr](Maegan141Cole117-521a2b92-7926-4348-0c8d-3bd3af6da538.phr) |
| 81810e78-8279-b01b-f0c8-62f7ebf85613 | Loriann967 Torp761 | appendicitis | 74400008 | [json](Loriann967_Torp761_81810e78-8279-b01b-f0c8-62f7ebf85613.json) | [phr](Ms.Loriann967Torp761-81810e78-8279-b01b-f0c8-62f7ebf85613.phr) |
| 6a9e8e6f-d4d8-f062-79cf-cbeda88dc2bf | Anne Goodwin | childhood asthma | 233678006 | [json](PatientJourneys/Anne_Goodwin_6a9e8e6f-d4d8-f062-79cf-cbeda88dc2bf.json) | [phr](PatientJourneys/Anne_Goodwin_6a9e8e6f-d4d8-f062-79cf-cbeda88dc2bf.phr) |
| 38ce6e87-ca56-e80c-f18b-d6056df7f0a9 | Randolph418 Eichmann909 | anemia | 271737000 | [json](Randolph418_Eichmann909_38ce6e87-ca56-e80c-f18b-d6056df7f0a9.json) | [phr](Mr.Randolph418Eichmann909-38ce6e87-ca56-e80c-f18b-d6056df7f0a9.phr) |
| d4beb77a-1183-7593-23e8-fb2a2694d55b | Gerald181 Murazik203 | child attention deficit disorder | 192127007 | [json](Gerald181_Murazik203_d4beb77a-1183-7593-23e8-fb2a2694d55b.json) | [phr](Gerald181Murazik203-d4beb77a-1183-7593-23e8-fb2a2694d55b.phr) |
| 9dad61c1-ab0e-fef2-260f-dec36788558d | Tomoko463 Anja508 Kunze215 | breast cancer - T2 category | 67673008 | [json](Tomoko463_Anja508_Kunze215_9dad61c1-ab0e-fef2-260f-dec36788558d.json) | [phr](Mrs.Tomoko463Kunze215-9dad61c1-ab0e-fef2-260f-dec36788558d.phr) |
| beee2c9a-931e-a2b2-4ae0-ff658b57f439 | Jarvis643 O'Hara248 | bronchitis | 10509002 | [json](Jarvis643_O'Hara248_91f9ab65-1933-2a48-94b1-b6fef00f7335.json) | [phr](Jarvis643_O'Hara248_91f9ab65-1933-2a48-94b1-b6fef00f7335.phr) |
| 088144ea-ce4b-fbb7-0167-2bb035387d7b | Georgie506 Daugherty69 | chronic kidney disease | 431856006 | [json](Georgie506_Daugherty69_088144ea-ce4b-fbb7-0167-2bb035387d7b.json) | [phr](Georgie506_Daugherty69_088144ea-ce4b-fbb7-0167-2bb035387d7b.json) |
| 69437c6f-772f-6aaf-34b9-b4d3f12d9eaf | Markus Ward | congestive heart failure | 88805009 | [json](PatientJourneys/Markus_Ward_69437c6f-772f-6aaf-34b9-b4d3f12d9eaf.json) | [phr](PatientJourneys/Markus_Ward_69437c6f-772f-6aaf-34b9-b4d3f12d9eaf.phr) |
| _d83b3432-e309-a5e1-8b6d-eb7da0c050d6 | Christoper325 Jakubowski832 | chronic obstructive pulmonary disease | 412776001 | [json](Christoper325_Jakubowski832_d83b3432-e309-a5e1-8b6d-eb7da0c050d6.json) | [phr](Mr.Adrian111Smith67-d5b0f2de-08c8-8259-68b0-af1fb66be392.phr) |
| 24f4d2f1-b4ef-0654-25a3-bdce21e7ceef | Wilma Nader | COVID-19 | 840539006 | [json](PatientJourneys/Wilma_Nader_24f4d2f1-b4ef-0654-25a3-bdce21e7ceef.json) | [phr](PatientJourneys/Wilma_Nader_24f4d2f1-b4ef-0654-25a3-bdce21e7ceef.phr) |
| a79c76c3-bd2f-3200-2912-20bfe99f7d4d | Rosario163 Delao225 | dementia | 386257007 | [json](Rosario163_Delao225_a79c76c3-bd2f-3200-2912-20bfe99f7d4d.json) | [phr](Ms.Rosario163Delao225-a79c76c3-bd2f-3200-2912-20bfe99f7d4d.phr) |
| 90fd51e4-3442-e231-1aa7-9e0c336319a0 | Nia310 Kihn564 | atopic dermatitis | 24079001 | [json](Nia310_Kihn564_90fd51e4-3442-e231-1aa7-9e0c336319a0.json) | [phr](Nia310Kihn564-90fd51e4-3442-e231-1aa7-9e0c336319a0.phr) |
| 7acef32e-71aa-5737-c892-16420d944e6e | Sal878 Langworth352 | renal dialysis | 265764009 | [json](Sal878_Langworth352_7acef32e-71aa-5737-c892-16420d944e6e.json) |   |
| 9532101f-6dc4-e18b-53ae-79a3230fdf70 | Ricky354 Boyle917 | epilepsy | 84757009 | [json](Ricky354_Boyle917_9532101f-6dc4-e18b-53ae-79a3230fdf70.json) | [phr](Mr.Ricky354Boyle917-9532101f-6dc4-e18b-53ae-79a3230fdf70.phr) |
| 7f7d92cb-d968-56f9-8ee9-108dfb3dd7ee | Vicente970 Botsford977 | gout | 90560007 | [json](Vicente970_Botsford977_7f7d92cb-d968-56f9-8ee9-108dfb3dd7ee.json) | [phr](Mr.Vicente970Botsford977-7f7d92cb-d968-56f9-8ee9-108dfb3dd7ee.phr) |
| 558aac8d-bd8a-e7fd-ca6e-824c192e9544 | Cyril535 Koepp521 | HIV | 165816005 | [json](Cyril535_Koepp521_558aac8d-bd8a-e7fd-ca6e-824c192e9544.json) | [phr](Mr.Christoper325Jakubowski832-d83b3432-e309-a5e1-8b6d-eb7da0c050d6.phr) |
| 963c7c3a-80ba-5c14-30e9-d3dcf83d6cd4 | Sina65 Ullrich385 | hospice | 385763009 | [json](Sina65_Ullrich385_963c7c3a-80ba-5c14-30e9-d3dcf83d6cd4.json) | [phr](Mrs.Sina65Ullrich385-963c7c3a-80ba-5c14-30e9-d3dcf83d6cd4.phr) |
| 97aa6ae5-d71e-f9df-c6dc-be3ae713690a | Kitty323 Farrah946 Lemke654 | hypertension | 59621000 | [json](Kitty323_Farrah946_Lemke654_97aa6ae5-d71e-f9df-c6dc-be3ae713690a.json) | [phr](Mrs.Kitty323Lemke654-97aa6ae5-d71e-f9df-c6dc-be3ae713690a.phr) |
| 95b19a58-09ae-d6dc-1cb5-532a78b0d3c7 | Shaunta614 Gala823 Sanford861 | idiopathic hypothyroidism | 83664006 | [json](Shaunta614_Gala823_Sanford861_95b19a58-09ae-d6dc-1cb5-532a78b0d3c7.json) |   |
| fecad5a2-6d95-36ed-7e4c-d47e9199e8cc | Charlotte28 Mireille557 Parisian75 | concussion | 62106007 | [json](Charlotte28_Mireille557_Parisian75_fecad5a2-6d95-36ed-7e4c-d47e9199e8cc.json) | [phr](Mrs.Charlotte28Parisian75-fecad5a2-6d95-36ed-7e4c-d47e9199e8cc.phr) |
| 13803def-e365-e248-e7ec-632533574c3c | Earl Carrillo | non-small cell lung cancer | 254637007 | [json](PatientJourneys/Earl_Carrillo_13803def-e365-e248-e7ec-632533574c3c.json) | [phr](PatientJourneys/Earl_Carrillo_13803def-e365-e248-e7ec-632533574c3c.phr) |
| 54e40745-9772-e4a4-b501-47ae63c99704 | Graig740 Tremblay80 | metabolic syndrome | 237602007 | [json](Graig740_Tremblay80_54e40745-9772-e4a4-b501-47ae63c99704.json) | [phr](Mr.Graig740Tremblay80-54e40745-9772-e4a4-b501-47ae63c99704.phr) |
| 91ed826b-b2d7-99fe-0be3-0439d18ecb2a | Natalia964 Fisher429 | opioid abuse | 5602001 | [json](Natalia964_Fisher429_91ed826b-b2d7-99fe-0be3-0439d18ecb2a.json) | [phr](Natalia964_Fisher429_91ed826b-b2d7-99fe-0be3-0439d18ecb2a.json) |
| 6fd8fee9-7fba-4446-5a2a-dfe9257e1631 | Vanessa263 Page791 Lang846 | osteoporosis | 64859006 | [json](Vanessa263_Page791_Lang846_6fd8fee9-7fba-4446-5a2a-dfe9257e1631.json) | [phr](Vanessa263_Page791_Lang846_6fd8fee9-7fba-4446-5a2a-dfe9257e1631.json) |
| a6e749b3-eff6-94d5-5ee2-fb4a6566deef | Marcella Schumm | normal pregnancy | 72892002 | [json](PatientJourneys/Marcella_Schumm_a6e749b3-eff6-94d5-5ee2-fb4a6566deef.json) | [phr](PatientJourneys/Marcella_Schumm_a6e749b3-eff6-94d5-5ee2-fb4a6566deef.json) |
| b722aff7-7d41-fea2-ca71-7770fc0a9eb7 | Scarlett814 Waneta858 Stamm704 | rheumatoid arthritis | 69896004 | [json](Scarlett814_Waneta858_Stamm704_b722aff7-7d41-fea2-ca71-7770fc0a9eb7.json) | [phr](Mrs.Scarlett814Stamm704-b722aff7-7d41-fea2-ca71-7770fc0a9eb7.phr) |
| c5328d38-7a8c-e245-dabe-2042022047eb | Yu876 Botsford977 | sepsis | 91302008 | [json](Yu876_Botsford977_c5328d38-7a8c-e245-dabe-2042022047eb.json) | [phr](Ms.Yu876Botsford977-c5328d38-7a8c-e245-dabe-2042022047eb.phr) |
| 2656be07-d463-10d2-bc57-a3fff6058858 | Gonzalo160 Gibson10 | obstructive sleep apnea syndrome | 78275009 | [json](Gonzalo160_Gibson10_2656be07-d463-10d2-bc57-a3fff6058858.json) | [phr](Mr.Gonzalo160Gibson10-2656be07-d463-10d2-bc57-a3fff6058858.phr) |
| 4fcce493-43ba-aa15-23e8-653d7648ab08 | Dee580 Boehm581 | sore throat | 43878008 | [json](Dee580_Boehm581_4fcce493-43ba-aa15-23e8-653d7648ab08.json) | [phr](Dee580Boehm581-4fcce493-43ba-aa15-23e8-653d7648ab08.phr) |
| d949d7bb-3bd7-b925-e72f-a314b6feb197 | Ariel183 Schmitt836 | urinary tract infection | 301011002 | [json](Ariel183_Schmitt836_d949d7bb-3bd7-b925-e72f-a314b6feb197.json) | [phr](Ms.Ariel183Schmitt836-d949d7bb-3bd7-b925-e72f-a314b6feb197.phr) |
| f966ba2e-50d2-df7f-a5b1-bbb59685eda5 | Stanley702 Ritchie586 | neoplasm of prostate | 126906006 | [json](Stanley702_Ritchie586_f92c770e-04aa-ff7c-fcf1-2a02166d032a.json) | [phr](Mr.Stanley702Ritchie586-f92c770e-04aa-ff7c-fcf1-2a02166d032a.phr) |
| 8dc4ac2f-691f-d83b-1bf0-ca4080ab0b4a | Wes853 DuBuque211 | posttraumatic stress disorder | 47505003 | [json](Wes853_DuBuque211_8dc4ac2f-691f-d83b-1bf0-ca4080ab0b4a.json) | [phr](Mr.Wes853DuBuque211-8dc4ac2f-691f-d83b-1bf0-ca4080ab0b4a.phr) |

### Patient Narratives

For additional research on patient narratives and the circumstances that shape many of the most challenging clinical cases, particularly with regard to social determinates of health, the Soft White Underbelly videos may be of interest. It often helps to hear accounts from a first-person perspective of the varied circumstances that lead to homelessness, incarceration, chronic illness, mental health episodes, disability, etc.

[Soft White Underbelly Videos](https://www.youtube.com/@SoftWhiteUnderbelly/videos)

### General References

* [Node on FHIR - Clinical Scenarios](https://github.com/clinical-meteor/clinical-scenarios)
* [SMART on FHIR Test Patient Data (Cerner)](https://docs.google.com/document/d/10RnVyF1etl_17pyCyK96tyhUWRbrTyEcqpwzW-Z-Ybs/edit)
* [Figma - Patient Personas (GoInvo)](https://www.figma.com/proto/MzUwuSOpldbZXQk4aYobgk/V2-Library?page-id=644%3A4036&node-id=1209%3A3275)
* [Pediatric Leukemia](https://pediatricimaging.org/diseases/leukemia/)
* [Synthea: Downloads](https://synthea.mitre.org/downloads)
* [The Coherent Dataset (9GB)](https://synthea-open-data.s3.amazonaws.com/coherent/coherent-11-07-2022.zip)

